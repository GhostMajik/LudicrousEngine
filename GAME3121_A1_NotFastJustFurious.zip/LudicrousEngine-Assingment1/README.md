# LudicrousEngine

** DEV NOTES **

Assets - Raw assets for game, not yet optimized

Documents - GDD, Testing ideas, any other documentation

Temp - Temp builds files and information goes here.

Test - Scripts and other assets used to assists in testing, not in final release.

Game - Release builds and files needed to run the game only.

Source -  Source code for the engine divided into subfolders here.

Library - Any extra external libraries can used go here.


